# Set path to input file
$inputFile = "C:\Diagnostics\BatteryInfoView\batteryhealth.txt"

# Initialize variables
$lines = Get-Content $inputFile
$found = $false

for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "Description\s+: Battery Health") {
        $found = $true
    }

    if ($found -and $lines[$i] -match "Value\s+:\s+(.*)") {
        $batteryHealth = $matches[1].Trim()
        Write-Output "                    Battery Health: $batteryHealth"

        break
    }
}