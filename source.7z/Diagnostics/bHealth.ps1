# Set path to input file
$inputFile = "C:\Diagnostics\BatteryInfoView\batteryhealth.txt"

# Read the file line by line
$lines = Get-Content $inputFile

$batteryHealth = $null

for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match "^Description\s+: Battery Health") {
        # Look ahead for "Value"
        for ($j = $i + 1; $j -lt $lines.Length; $j++) {
            if ($lines[$j] -match "^Value\s+: (.+)$") {
                $batteryHealth = $matches[1].Trim()
                break
            }
        }
        break
    }
}

if ($batteryHealth) {
    Write-Output "Battery Health: $batteryHealth"
} else {
    Write-Output "Battery Health not found."
}