[CmdletBinding()]
param()

# -------------------------------
# System Model Information
# -------------------------------
Write-Verbose "Pulling System Model Information..."
$system = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
$bios = Get-CimInstance -ClassName Win32_BIOS -ErrorAction SilentlyContinue

if ($system -and $bios) {
    $manufacturer = $system.Manufacturer
    $model = $system.Model
    $serialNumber = $bios.SerialNumber

    Write-Host "System Manufacturer : $manufacturer" -ForegroundColor Green
    Write-Host "System Model        : $model" -ForegroundColor Green
    Write-Host "System Serial Number: $serialNumber" -ForegroundColor Green
    Write-Host ""
} else {
    Write-Warning "Unable to retrieve system model information."
}

# -------------------------------
# CPU Information
# -------------------------------
Write-Verbose "Pulling CPU Info..."
$cpuData = Get-CimInstance -ClassName Win32_Processor -ErrorAction SilentlyContinue
if (!$cpuData) {
    Write-Warning "CPU information not found."
} else {
    # Select relevant CPU properties and rename for clarity
    $cpuInfo = $cpuData | Select-Object @{Name='CPU Name'; Expression={$_.Name}},
                                   @{Name='Cores'; Expression={$_.NumberOfCores}},
                                   @{Name='Threads'; Expression={$_.NumberOfLogicalProcessors}}
}

# -------------------------------
# GPU Information
# -------------------------------
Write-Verbose "Pulling GPU Info..."
# Query the registry for accurate VRAM sizes (handles GPUs with >4GB VRAM)&#8203;:contentReference[oaicite:1]{index=1}
$regPath  = "HKLM:\SYSTEM\ControlSet001\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0*"
$adapterMemory = Get-ItemProperty -Path $regPath -Name "HardwareInformation.AdapterString", "HardwareInformation.qwMemorySize" -ErrorAction SilentlyContinue

$gpuData = Get-CimInstance -ClassName Win32_VideoController -ErrorAction SilentlyContinue
if (!$gpuData) {
    Write-Warning "GPU information not found."
} else {
    # Build GPU info objects with corrected VRAM values
    $gpuInfo = foreach ($gpu in $gpuData) {
        # Find matching registry entry by adapter name (if available)
        $regEntry = $null
        if ($adapterMemory) {
            $regEntry = $adapterMemory | Where-Object { $_."HardwareInformation.AdapterString" -eq $gpu.Name }
        }
        # Determine VRAM in GB (use registry value if present; otherwise fall back to AdapterRAM)
        $vramGB = $null
        if ($regEntry -and $regEntry."HardwareInformation.qwMemorySize") {
            $vramGB = [Math]::Round($regEntry."HardwareInformation.qwMemorySize" / 1GB, 2)
        } elseif ($gpu.AdapterRAM) {
            $vramGB = [Math]::Round($gpu.AdapterRAM / 1GB, 2)
        }
        # Output object for this GPU
        [PSCustomObject]@{
            Name           = $gpu.Name
            "Video Processor" = $gpu.VideoProcessor
            "Driver Version"  = $gpu.DriverVersion
            "VRAM (GB)"     = if ($vramGB) { $vramGB } else { "N/A" }
        }
    }
}

# -------------------------------
# RAM Information
# -------------------------------
Write-Verbose "Pulling RAM Info..."
$ramData = Get-CimInstance -ClassName Win32_PhysicalMemory -ErrorAction SilentlyContinue
if (!$ramData) {
    Write-Warning "Memory (RAM) information not found."
} else {
    # Select and format RAM module properties (BankLabel, Capacity in GB, Speed in MHz)
    $ramInfo = $ramData | Select-Object @{Name='Bank Label'; Expression={$_.BankLabel}},
                                   @{Name='Capacity (GB)'; Expression={[Math]::Round($_.Capacity / 1GB, 2)}},
                                   @{Name='Speed (MHz)'; Expression={$_.Speed}}
}

# -------------------------------
# Total Installed RAM
# -------------------------------


# -------------------------------
# Storage Drive Information
# -------------------------------
Write-Verbose "Pulling Storage Info..."

# Gather data from relevant classes
$physicalDrives  = Get-CimInstance Win32_DiskDrive -ErrorAction SilentlyContinue
$partitions      = Get-CimInstance Win32_DiskPartition -ErrorAction SilentlyContinue
$logicalDisks    = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue
$logicalToPart   = Get-CimInstance Win32_LogicalDiskToPartition -ErrorAction SilentlyContinue

$driveInfo = @()

foreach ($map in $logicalToPart) {
    $logicalDrive = ($map.Dependent -split '"')[1]
    $partition    = ($map.Antecedent -split '"')[1]

    $partitionObj = $partitions | Where-Object { $_.DeviceID -eq $partition }
    $logicalObj   = $logicalDisks | Where-Object { $_.DeviceID -eq $logicalDrive }

    if ($partitionObj -and $logicalObj) {
        $physDrive = $physicalDrives | Where-Object { $_.Index -eq $partitionObj.DiskIndex }

        $model = $physDrive.Model
        $isSSD = $physDrive.MediaType -match "SSD" -or $physDrive.Model -match "SSD"

        $driveInfo += [PSCustomObject]@{
            'Drive Letter'     = $logicalObj.DeviceID
            'Volume Label'     = $logicalObj.VolumeName
            'File System'      = $logicalObj.FileSystem
            'Size (GB)'        = [Math]::Round($logicalObj.Size / 1GB, 2)
            'Free Space (GB)'  = [Math]::Round($logicalObj.FreeSpace / 1GB, 2)
            'Drive Model'      = $model
            'Drive Type'       = if ($isSSD) { "SSD" } else { "HDD" }
        }
    }
}

# -------------------------------
# Output (Formatted Tables)
# -------------------------------
# Output results in structured tables with headings
if ($cpuInfo) {
    Write-Host "`nCPU Information:" -ForegroundColor Green
    $cpuInfo | Format-Table -AutoSize
}
if ($gpuInfo) {
    Write-Host "`nGPU Information:" -ForegroundColor Green
    $gpuInfo | Format-Table -AutoSize
}
if ($ramInfo) {
    Write-Host "`nMemory (RAM) Modules:" -ForegroundColor Green
    $ramInfo | Format-Table -AutoSize
    if ($ramData) {
    $totalRAM = ($ramData | Measure-Object -Property Capacity -Sum).Sum
    $totalRAMGB = [Math]::Round($totalRAM / 1GB, 2)
    Write-Host "`nInstalled Memory (RAM): $totalRAMGB GB" -ForegroundColor Green
    Write-Host ""
    Write-Host ""
}
}
if ($driveInfo) {
    Write-Host "`nStorage Drives:" -ForegroundColor Green
    $driveInfo | Format-Table -AutoSize
}
